function myFunc(...rest){
  
    for (i = 0; i < arguments.length; i++) {
       
        console.log(arguments[4]**2);
        console.log(arguments[6]**2);
        let round = console.log(arguments[7]**2);
        // round = round.toFixed(2); //toUpperCase() ვერ კითხულობს 
        // console.log(round);
        console.log(round);
        console.log(...rest);
        
        
        return rest[i]; 
        
    }
    
  if(typeof rest === 'number'){
      return rest;
  }
  console.log(...rest);
}

let oldArr = myFunc('MJ 23', 'Magic Johnson 32', null, undefined, 23, 'Denis Rodman 91', 91, 32.3);

let newArr = [...oldArr];
newArr.push(oldArr);
console.log(newArr);

function newArray(){
    myFunc();
    
    if(newArray.length % 2 === 0 && console.log('ვერ დავიმსახსოვრე კეტი და ლუწი')){
        
        return newArr();
    }
}
    let addArray = [];
    addArray.push(oldArr);
    console.log(addArray);


function myString(){
  newArray();
    console.log(arguments[0]);
    console.log(arguments[1]);
    console.log(arguments[5]);
}
myString('MJ 23', 'Magic Johnson 32', null, undefined, 23, 'Denis Rodman 91', 91, 32.3);
let myStringArr = [];
myStringArr.push(oldArr);
console.log(myStringArr); // მასივი არ მაქვს და ვერ ამატებს 



//=====================================================================================
 //დავალება 2)
 //დავალება 3) 2)
 //დავალება 4) 3)

// const arr =  [ 4, 5, 11, 2, 9, 99, 1092, 1]; 

// const sortedArray = arr.sort(function(a, b, ...rest){
//     return a - b - rest;
// }).filter((item) => {
//     return item % 2 === 0;
// }).reduce((previous, current) => {
//     return current * previous;
// });

// console.log(arr);
// console.log(sortedArray);

//=======================================================================================
// დავალება 5)

var str = [ 'HELLO', 'WORLD', 'JS', 'GEOLAB'].map(v => {
    return v.toLowerCase();
  });
  
  let changedArr = [];

for( i = 0; i < str.length; i++){
    changedArr.push(str[i].charAt(0).toUpperCase() + str[i].slice(1));
}

  console.log(changedArr);




